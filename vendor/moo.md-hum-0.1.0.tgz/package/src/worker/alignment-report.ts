import type { Pull, PullRequests } from "../adapters/pull-requests.ts";
import { alignmentComment, gatesAlignment } from "../decide/alignment.ts";
import type { LandContext } from "./land.ts";

/**
 * Comments on the pull request what the alignment call made of the change, once per head, while the call's rate is
 * below the bar. Above the bar the call raises levels and needs no report.
 */
export const reportAlignment = async (ctx: LandContext, pulls: PullRequests, pull: Pull, head: string): Promise<void> => {
	const alignment = ctx.state.landings.get(ctx.id)?.alignment;

	if (!alignment || gatesAlignment(ctx.config.hum)) return;

	await ctx.state.ops.once(
		{ itemId: ctx.id, run: "merge", attempt: 0, op: `alignment:${head}` },
		{ holds: async () => false, run: () => pulls.comment(pull, alignmentComment(alignment, ctx.config.hum)) },
	);
};
