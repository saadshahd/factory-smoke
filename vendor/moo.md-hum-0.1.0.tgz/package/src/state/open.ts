import { spawnSync } from "node:child_process";
import { join, resolve } from "node:path";
import { Kind } from "../config/schema.ts";
import { EventLog } from "./events.ts";
import { Faults } from "./faults.ts";
import { type Codec, Items } from "./items.ts";
import { OpKeys } from "./ops.ts";
import { Records } from "./records.ts";
import { RunRecords } from "./runs.ts";
import { Limit, Parked, ReadyList, Spent } from "./saved.ts";

/** On the Mac and in a clone, state lives in the repo's git common dir, so every worktree shares it. */
export const defaultStateDir = (cwd: string): string => {
	const found = spawnSync("git", ["rev-parse", "--git-common-dir"], { cwd, encoding: "utf8" });

	if (found.status !== 0) throw new Error(`${cwd} is not inside a git repository: ${found.stderr.trim()}`);

	return join(resolve(cwd, found.stdout.trim()), "hum");
};

export type StateOptions = Codec & { readonly now?: () => number };

/** Everything the engine saves between runs, under one folder. */
export const openState = (dir: string, { now = Date.now, ...codec }: StateOptions = {}) => {
	const faults = new Faults(join(dir, "faults"), now);

	return {
		dir,
		/** U1: the one status file for the repo. */
		statusPath: join(dir, "status.json"),
		/** The worker's heartbeat, one file the service unit reads (R7). */
		heartbeatPath: join(dir, "heartbeat.json"),
		/** U5: the hook drops one file here per posted answer; its content is the item id. */
		inbox: join(dir, "inbox"),
		faults,
		items: new Items(join(dir, "items"), faults, now, codec),
		events: new EventLog(join(dir, "events"), now),
		ops: new OpKeys(join(dir, "ops"), now),
		runs: new RunRecords(join(dir, "runs"), now),
		parked: new Records(join(dir, "parked"), Parked),
		spent: new Records(join(dir, "spent"), Spent),
		/** Earlier kinds by `<machine id>@<version>`, for `items.restore` (V3). */
		kinds: new Records(join(dir, "kinds"), Kind),
		limit: new Records(join(dir, "limit"), Limit),
		ready: new Records(join(dir, "ready"), ReadyList),
	};
};

export type State = ReturnType<typeof openState>;
